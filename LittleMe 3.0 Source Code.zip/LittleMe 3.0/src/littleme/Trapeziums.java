/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package littleme;

import java.awt.event.ActionEvent;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.SwingWorker;
import javax.swing.Timer;
import static littleme.LittleMe.random;
import static littleme.LittleMe.sound;
import static littleme.Square.currentWord;

/**
 *
 * @author owoye001
 */
public class Trapeziums {

    double area; //the area of the trapezium

    double trapezium; //the perimeter of the trapezium

    double base1; // the length of the first base

    double base2; // the length of the second base

    double height; // the perpendicular height

    double side1; // length of first side

    double side2; // length of second side

    double perimeter; //perimeter of the trapezium

    String known; //to determine the known values....in case of equation solving ..

    Boolean SectorOpen;  //to determine whether the loop for this section keep runnning.

    public Trapeziums() {

        SectorOpen = true; //the loop is set to run until it is stopped by the user. 

        do {

            known = "A1";  //used for resetting and to prevent null exception

            LittleMe.varQuest("length of one base", "trapezium");

            if (LittleMe.userOption.equalsIgnoreCase("y")) {

                base1 = LittleMe.VarCollector(base1, "base (first one)");

                known = "B1"; //known variables.

                System.out.println();

                LittleMe.varQuest("length of second base", "trapezium");

                if (LittleMe.userOption.equalsIgnoreCase("y")) {

                    System.out.println(); //for formatting purposes only 

                    base2 = LittleMe.VarCollector(base2, "length (second one)");

                    known = "B1B2"; // known variables

                    System.out.println();

                    LittleMe.varQuest("perpendicular height", "trapezium");

                    if (LittleMe.userOption.equalsIgnoreCase("y")) {

                        System.out.println(); //for formatting purposes only 

                        height = LittleMe.VarCollector(height, "height");

                        known = "B1B2H"; // known variables

                        System.out.println();

                        LittleMe.Question("Are you interested in calculating the perimeter of the trapezium?");

                        if (LittleMe.userOption.equalsIgnoreCase("y")) {

                            System.out.println(); //for formatting purposes only 

                            LittleMe.varQuest("length of one side", "trapezium");

                            if (LittleMe.userOption.equalsIgnoreCase("y")) {

                                System.out.println(); //for formatting purposes only 

                                side1 = LittleMe.VarCollector(side1, "side (first one)");

                                known = "B1B2HS1"; // known variables

                                LittleMe.varQuest("length of second side", "trapezium");

                                if (LittleMe.userOption.equalsIgnoreCase("y")) {

                                    System.out.println(); //for formatting purposes only 

                                    side2 = LittleMe.VarCollector(side2, "side (second one)");

                                    known = "B1B2HS1S2"; // known variables

                                    //will print perimeter.
                                } else if (LittleMe.userOption.equalsIgnoreCase("n")) {
                                    System.out.println();

                                    LittleMe.InfoS("I have been thinking....Not enough information to calculate perimeter");
                                }

                            } else if (LittleMe.userOption.equalsIgnoreCase("n")) {
                                System.out.println();

                                LittleMe.InfoS("I have been thinking....Not enough information to calculate perimeter");
                            }
                        } else if (LittleMe.userOption.equalsIgnoreCase("n")) {
                            System.out.println();
                            LittleMe.Message("Okay"); //user interraction
                        }
                    } else if (LittleMe.userOption.equalsIgnoreCase("n")) {
                        System.out.println();

                        LittleMe.InfoS("I have been thinking....Not enough information to calculate area");
                    }
                } else if (LittleMe.userOption.equalsIgnoreCase("n")) {
                    System.out.println();

                    LittleMe.InfoS("I have been thinking....Not enough information to calculate area");
                }
            } else if (LittleMe.userOption.equalsIgnoreCase("n")) {
                System.out.println();

                LittleMe.InfoS("I have been thinking....Not enough information to calculate area");
            }

            //this print out the required answers
            if (known.equalsIgnoreCase("B1B2H")) {

                System.out.println(); // for formating purposes only

                LittleMe.Thinking();

                System.out.println(LittleMe.cSpace() + "The area of the trapezium is " + getArea());

                System.out.println(); // for formating purposes only

            }

            if (known.equalsIgnoreCase("B1B2HS1S2")) {

                System.out.println(); // for formating purposes only

                LittleMe.Thinking();

                System.out.println(LittleMe.cSpace() + "The perimeter of the trapezium is " + getPerimeter());

                System.out.println(); // for formating purposes only

            }

            //ask user if they want to keep the section open
            System.out.println();

            LittleMe.Question("Do you still want to work on more trapeziums?");

            if (LittleMe.userOption.equalsIgnoreCase("y")) {

                System.out.println();
                System.out.println();

            } else if (LittleMe.userOption.equalsIgnoreCase("n")) {

                SectorOpen = false; //closes the section

                System.out.println();
                System.out.println();

                LittleMe.Message("Okay, I will close the section"); //user interraction

            }

        } while (SectorOpen == true); //end of do loop

        //redraw the GUI.
        LittleMe.linebreak();
        LittleMe.printConsole();

    }

    public Trapeziums(boolean GUI) {

        SwingUpdater trapeziumshape = new SwingUpdater();
        trapeziumshape.execute();

    }

    public class SwingUpdater extends SwingWorker<Void, String> {

        @Override
        protected Void doInBackground() throws Exception {
            //-----------------------------------------------------------
            known = "A1";  //used for resetting and to prevent null exception

            int n = JOptionPane.showConfirmDialog(null, "Do you know length of one base of the trapezium", "Little Me", JOptionPane.YES_NO_OPTION);

            if (n == JOptionPane.YES_OPTION) {

                boolean correct = false;

                do {

                    try {
                        base1 = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter the value of base (first one) of the trapezium",
                                "Little Me", JOptionPane.QUESTION_MESSAGE));
                        correct = true;
                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(null, "Invalid Input", "Little Me", JOptionPane.ERROR_MESSAGE);
                    }

                } while (correct == false);

                known = "B1"; //known variables.

                n = JOptionPane.showConfirmDialog(null, "Do you know length of second base of the trapezium", "Little Me", JOptionPane.YES_NO_OPTION);

                if (n == JOptionPane.YES_OPTION) {

                    correct = false;

                    do {

                        try {
                            base2 = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter the length (second one) of the trapezium",
                                    "Little Me", JOptionPane.QUESTION_MESSAGE));
                            correct = true;
                        } catch (Exception e) {
                            JOptionPane.showMessageDialog(null, "Invalid Input", "Little Me", JOptionPane.ERROR_MESSAGE);
                        }

                    } while (correct == false);

                    known = "B1B2"; // known variables

                    n = JOptionPane.showConfirmDialog(null, "Do you know perpendicular height of the trapezium", "Little Me", JOptionPane.YES_NO_OPTION);

                    if (n == JOptionPane.YES_OPTION) {

                        correct = false;

                        do {

                            try {
                                height = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter the perpendicular height of the trapezium",
                                        "Little Me", JOptionPane.QUESTION_MESSAGE));
                                correct = true;
                            } catch (Exception e) {
                                JOptionPane.showMessageDialog(null, "Invalid Input", "Little Me", JOptionPane.ERROR_MESSAGE);
                            }

                        } while (correct == false);

                        known = "B1B2H"; // known variables

                        n = JOptionPane.showConfirmDialog(null, "Do you know the length of one side of the trapezium", "Little Me", JOptionPane.YES_NO_OPTION);

                        if (n == JOptionPane.YES_OPTION) {

                            correct = false;

                            do {

                                try {
                                    side1 = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter the length of the side (first one) of the trapezium",
                                            "Little Me", JOptionPane.QUESTION_MESSAGE));
                                    correct = true;
                                } catch (Exception e) {
                                    JOptionPane.showMessageDialog(null, "Invalid Input", "Little Me", JOptionPane.ERROR_MESSAGE);
                                }

                            } while (correct == false);

                            known = "B1B2HS1"; // known variables

                            n = JOptionPane.showConfirmDialog(null, "Do you know the length of second side of the trapezium", "Little Me", JOptionPane.YES_NO_OPTION);

                            if (n == JOptionPane.YES_OPTION) {

                                correct = false;

                                do {

                                    try {
                                        side2 = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter the length of side (second one) trapezium",
                                                "Little Me", JOptionPane.QUESTION_MESSAGE));
                                        correct = true;
                                    } catch (Exception e) {
                                        JOptionPane.showMessageDialog(null, "Invalid Input", "Little Me", JOptionPane.ERROR_MESSAGE);
                                    }

                                } while (correct == false);

                                known = "B1B2HS1S2"; // known variables

                                //will print perimeter.
                            } else {

                                publish("I have been thinking....Not enough information to calculate perimeter");
                            }

                        } else {

                            publish("I have been thinking....Not enough information to calculate perimeter");
                        }
                    } else {

                        publish("Okay"); //user interraction
                    }
                } else {

                    publish("I have been thinking....Not enough information to calculate area");
                }
            } else {

                publish("I have been thinking....Not enough information to calculate area");
            }

            //this print out the required answers
            if (known.equalsIgnoreCase("B1B2H")) {

                startToThink();

                publish("The area of the trapezium is " + getArea());

            }

            if (known.equalsIgnoreCase("B1B2HS1S2")) {

                startToThink();

                publish("The perimeter of the trapezium is " + getPerimeter());

            }
            //------------------------------------------------------------------------
            return null;
        }

        public void startToThink() {
            //-----------------------------------------
            currentWord = "\nThinking .";

            publish(currentWord);
            int number; //how long the timer will run
            do {
                number = random.nextInt(4000);
            } while (number <= 3000);

            LittleMe.playsound("calculating.mp3"); //this plays the calculation sound

            Timer t = new Timer(3000, (ActionEvent ae) -> {
                currentWord += currentWord + ".";
                publish(currentWord); //update the current world
            });
            t.start(); //starting the timer here 

            //this causes the thread to sleep again
            try {
                Thread.sleep(number);

            } catch (InterruptedException ex) {

            }
            t.stop(); //stop the timer 
            sound.stop(); //tSystem.out.prihis stops the sound file
            currentWord = "\n"; //to tell the user that computing is done
            publish(currentWord);
            LittleMe.playsound("beep.mp3"); //a sound to say it's done.
        }

        @Override
        protected void process(final List<String> chunks) {
    // Updates the messages text area
    /*for (String string : chunks) {
             SquareGUI.JTextAreaOutput.setText(SquareGUI.JTextAreaOutput.getText() + "\n\n" + string);
             }*/

            // Updates the messages text area
            for (final String string : chunks) {
                TrapeziumGUI.JTextAreaOutput.append(string);
                TrapeziumGUI.JTextAreaOutput.append("\n");

            }
        }

    }

    //calculate the area of the triangle using base x perpendicular height.
    public final String getArea() {
        //using 1/2 base * height

        area = (0.5000 * (base1 + base2)) * height;

        return String.format("%.04f", area);

    }

    //calculates the perimeter
    public final String getPerimeter() {
        perimeter = base1 + base2 + side1 + side1;

        return String.format("%.04f", perimeter);

    }

}
