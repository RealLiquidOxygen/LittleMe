/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package littleme;

import java.awt.event.ActionEvent;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.SwingWorker;
import javax.swing.Timer;
import static littleme.LittleMe.random;
import static littleme.LittleMe.sound;
import static littleme.Square.currentWord;

/**
 *
 * @author owoye001
 */
//this class states the properties of a rectangle
public class Rectangle {

    double area; //the area of the square

    double length; //length of one side of the square

    double width; //width of one sides of the rectangle

    String known; //to determine the known values....in case of equation solving ..

    Boolean SectorOpen;  //to determine whether the loop for this section keep runnning. 

    public Rectangle() {

        SectorOpen = true; //the loop is set to run until it is stopped by the user. 

        do {

            known = "A1";  //used for resetting and to prevent null exception

            LittleMe.varQuest("length", "rectangle");

            if (LittleMe.userOption.equalsIgnoreCase("y")) {

                length = LittleMe.VarCollector(length, "length");

                known = "l";

                System.out.println();

                LittleMe.varQuest("width", "rectangle");

                if (LittleMe.userOption.equalsIgnoreCase("y")) {

                    System.out.println();

                    width = LittleMe.VarCollector(width, "width");

                    known = "lw"; // known variables length and area

                    //print out the area
                } else if (LittleMe.userOption.equalsIgnoreCase("n")) {

                    System.out.println();

                    LittleMe.varQuest("area", "rectangle");

                    if (LittleMe.userOption.equalsIgnoreCase("y")) {

                        System.out.println();

                        area = LittleMe.VarCollector(area, "area");

                        known = "la"; // known variables length and area

                        //print out the width
                    } else if (LittleMe.userOption.equalsIgnoreCase("n")) {

                        System.out.println();

                        LittleMe.InfoS("I am sorry, I cannot help you with this problem. Not enough information");
                    }
                }

            } else if (LittleMe.userOption.equalsIgnoreCase("n")) {

                System.out.println();

                LittleMe.varQuest("width", "rectangle");

                if (LittleMe.userOption.equalsIgnoreCase("y")) {

                    System.out.println();

                    width = LittleMe.VarCollector(width, "width");

                    known = "w";

                    System.out.println();

                    LittleMe.varQuest("area", "rectangle");

                    if (LittleMe.userOption.equalsIgnoreCase("y")) {

                        System.out.println();

                        area = LittleMe.VarCollector(area, "area");

                        known = "wa"; // known variables width and area

                        //print the length
                    } else if (LittleMe.userOption.equalsIgnoreCase("n")) {

                        System.out.println();

                        LittleMe.InfoS("I am sorry, I cannot help you with this problem. Not enough information");
                    }

                } else if (LittleMe.userOption.equalsIgnoreCase("n")) {

                    known = "nothing"; //no variable entered...this is done to prevent null pointer exception.

                    System.out.println();

                    LittleMe.InfoS("I am sorry, I cannot help you with this problem. Not enough information");
                }
            }

            //this print out the required answers
            if (known.equalsIgnoreCase("la")) {
                //this produces the answer
                System.out.println(); // for formating purposes only

                LittleMe.Thinking();

                System.out.println(LittleMe.cSpace() + "The width of the rectangle is " + getWidth());

                System.out.println(); // for formating purposes only
            }
            if (known.equalsIgnoreCase("wa")) {
                //this produces the answer
                System.out.println(); // for formating purposes only

                LittleMe.Thinking();

                System.out.println(LittleMe.cSpace() + "The length of the rectangle is " + getLength());

                System.out.println(); // for formating purposes only
            }
            if (known.equalsIgnoreCase("lw")) {
                //this produces the answer
                System.out.println(); // for formating purposes only

                LittleMe.Thinking();

                System.out.println(LittleMe.cSpace() + "The area of the rectangle is " + getArea());

                System.out.println(); // for formating purposes only

            }
            //ask user if they want to keep the section open

            System.out.println();

            LittleMe.Question("Do you still want to work on more rectangles?");

            if (LittleMe.userOption.equalsIgnoreCase("y")) {

                System.out.println();
                System.out.println();

            } else if (LittleMe.userOption.equalsIgnoreCase("n")) {

                SectorOpen = false; //closes the section

                System.out.println();
                System.out.println();

                LittleMe.Message("Okay, I will close the section"); //user interraction

            }
        } while (SectorOpen == true); //ends the loop for this section of the program
        //redraw the GUI.
        LittleMe.linebreak();

        LittleMe.printConsole();

    }

    public Rectangle(boolean GUI) {

        SwingUpdater rectangle = new SwingUpdater();
        rectangle.execute();
    }

    public class SwingUpdater extends SwingWorker<Void, String> {

        @Override
        protected Void doInBackground() throws Exception {
            //-----------------------------------------------------------
            known = "A1";  //used for resetting and to prevent null exception

            int n = JOptionPane.showConfirmDialog(null, "Do you know the length of the rect"
                    + "angle", "Little Me", JOptionPane.YES_NO_OPTION);

            if (n == JOptionPane.YES_OPTION) {

                boolean correct = false;

                do {

                    try {
                        length = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter the known length of the rectangle",
                                "Little Me", JOptionPane.QUESTION_MESSAGE));
                        correct = true;
                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(null, "Invalid Input", "Little Me", JOptionPane.ERROR_MESSAGE);
                    }

                } while (correct == false);

                known = "l";

                n = JOptionPane.showConfirmDialog(null, "Do you know the width of the rect"
                        + "angle", "Little Me", JOptionPane.YES_NO_OPTION);

                if (n == JOptionPane.YES_OPTION) {

                    correct = false;

                    do {

                        try {
                            width = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter the known width of the rectangle",
                                    "Little Me", JOptionPane.QUESTION_MESSAGE));
                            correct = true;
                        } catch (Exception e) {
                            JOptionPane.showMessageDialog(null, "Invalid Input", "Little Me", JOptionPane.ERROR_MESSAGE);
                        }

                    } while (correct == false);

                    known = "lw"; // known variables length and area

                    //print out the area
                } else {

                    n = JOptionPane.showConfirmDialog(null, "Do you know the area of the rect"
                            + "angle", "Little Me", JOptionPane.YES_NO_OPTION);

                    if (n == JOptionPane.YES_OPTION) {

                        do {

                            try {
                                area = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter the known area of the rectangle",
                                        "Little Me", JOptionPane.QUESTION_MESSAGE));
                                correct = true;
                            } catch (Exception e) {
                                JOptionPane.showMessageDialog(null, "Invalid Input", "Little Me", JOptionPane.ERROR_MESSAGE);
                            }

                        } while (correct == false);

                        known = "la"; // known variables length and area

                        //print out the width
                    } else {

                        publish("I am sorry, I cannot help you with this problem. "
                                + "Not enough information");
                    }
                }

            } else {

                n = JOptionPane.showConfirmDialog(null, "Do you know the width of the rect"
                        + "angle", "Little Me", JOptionPane.YES_NO_OPTION);

                if (n == JOptionPane.YES_OPTION) {

                    boolean correct = false;

                    do {

                        try {
                            width = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter the known width of the rectangle",
                                    "Little Me", JOptionPane.QUESTION_MESSAGE));
                            correct = true;
                        } catch (Exception e) {
                            JOptionPane.showMessageDialog(null, "Invalid Input", "Little Me", JOptionPane.ERROR_MESSAGE);
                        }

                    } while (correct == false);

                    known = "w";

                    n = JOptionPane.showConfirmDialog(null, "Do you know the area of the rect"
                            + "angle", "Little Me", JOptionPane.YES_NO_OPTION);

                    if (n == JOptionPane.YES_OPTION) {

                        correct = false;

                        do {

                            try {
                                area = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter the known area of the rectangle",
                                        "Little Me", JOptionPane.QUESTION_MESSAGE));
                                correct = true;
                            } catch (Exception e) {
                                JOptionPane.showMessageDialog(null, "Invalid Input", "Little Me", JOptionPane.ERROR_MESSAGE);
                            }

                        } while (correct == false);

                        known = "wa"; // known variables width and area

                        //print the length
                    } else {

                        publish("I am sorry, I cannot help you with this problem. "
                        );
                    }

                } else {

                    known = "nothing"; //no variable entered...this is done to prevent null pointer exception.

                    publish("I am sorry, I cannot help you with this problem. "
                    );
                }
            }

            //this print out the required answers
            if (known.equalsIgnoreCase("la")) {

                startToThink();

                publish("The width of the rectangle is " + getWidth());
            }
            if (known.equalsIgnoreCase("wa")) {
                startToThink();
                publish("The length of the rectangle is " + getLength());
            }
            if (known.equalsIgnoreCase("lw")) {

                startToThink();

                publish("The area of the rectangle is " + getArea());

            }

            //------------------------------------------------------------------------
            return null;
        }

        public void startToThink() {
            //-----------------------------------------
            currentWord = "\nThinking .";

            publish(currentWord);
            int number; //how long the timer will run
            do {
                number = random.nextInt(4000);
            } while (number <= 3000);

            LittleMe.playsound("calculating.mp3"); //this plays the calculation sound

            Timer t = new Timer(3000, (ActionEvent ae) -> {
                currentWord += currentWord + ".";
                publish(currentWord); //update the current world
            });
            t.start(); //starting the timer here 

            //this causes the thread to sleep again
            try {
                Thread.sleep(number);

            } catch (InterruptedException ex) {

            }
            t.stop(); //stop the timer 
            sound.stop(); //tSystem.out.prihis stops the sound file
            currentWord = "\n"; //to tell the user that computing is done
            publish(currentWord);
            LittleMe.playsound("beep.mp3"); //a sound to say it's done.
        }

        @Override
        protected void process(final List<String> chunks) {
    // Updates the messages text area
    /*for (String string : chunks) {
             SquareGUI.JTextAreaOutput.setText(SquareGUI.JTextAreaOutput.getText() + "\n\n" + string);
             }*/

            // Updates the messages text area
            for (final String string : chunks) {
                RectangleGUI.JTextAreaOutput.append(string);
                RectangleGUI.JTextAreaOutput.append("\n");

            }
        }

    }

    //calculates the width
    public final String getWidth() {
        width = area / length;

        return String.format("%.04f", width);
    }

    //calculates the length
    public final String getLength() {
        length = area / width;
        return String.format("%.04f", length);
    }

    //calculates the ares
    public final String getArea() {
        area = length * width;
        return String.format("%.04f", area);
    }

}
