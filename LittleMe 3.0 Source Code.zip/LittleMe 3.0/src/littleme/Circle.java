/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package littleme;

import java.awt.event.ActionEvent;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.SwingWorker;
import javax.swing.Timer;
import static littleme.LittleMe.random;
import static littleme.LittleMe.sound;
import static littleme.Square.currentWord;

/**
 *
 * @author owoye001
 */
public class Circle {

    double area; //the area of the circle

    double radius; //length of the radius

    double sectorarea; //width of one sides of the rectangle

    double arclength; //length of an arc

    double perimeter; //circumference of the circle

    double angles; //angle in degrees

    String known; //to determine the known values....in case of equation solving ..

    Boolean sector = false; // to determine whether the user is interested in sector calculation

    Boolean sectorGUI = false;

    Boolean SectorOpen; //to determine whether this section of the program keep opened

    public Circle() {

        SectorOpen = true;

        do {

            known = "A1";  //used for resetting and to prevent null exception

            LittleMe.varQuest("radius", "circle"); //ask the radius of the circle

            if (LittleMe.userOption.equalsIgnoreCase("y")) {

                System.out.println();

                radius = LittleMe.VarCollector(radius, "radius"); //collects the value for the radius of the circle, with error checking

                known = "r";

                System.out.println();

                LittleMe.Message("Excellent"); //print out a message to the user

                System.out.println(); // for formating purposes only

                LittleMe.Thinking(); //effects and sound

                System.out.println(LittleMe.cSpace() + "The area of the circle is " + getArea());

                System.out.println(); // for formating purposes only

                LittleMe.Thinking(); //effects and sound

                System.out.println(LittleMe.cSpace() + "The circumference of the circle is " + getCircumference());

                System.out.println(); // for formating purposes only

                LittleMe.Question("Are you interested in calculating a piece of the circle (Sectors)");

                if (LittleMe.userOption.equalsIgnoreCase("y")) {

                    System.out.println();

                    angles = LittleMe.VarCollector(angles, "angles (degree)");

                    sector = true; //user is interested in sectors

                } else if (LittleMe.userOption.equalsIgnoreCase("n")) {

                    System.out.println();

                    LittleMe.Message("Okay"); //user interraction

                }

            } else if (LittleMe.userOption.equalsIgnoreCase("n")) //DOES NOT KNOW THE RADIUS HERE...TRYING TO FIND IT
            {
                System.out.println();

                LittleMe.Message("Let's find the radius of the circle");

                System.out.println(); // for formating purposes only

                LittleMe.varQuest("area", "circle");

                if (LittleMe.userOption.equalsIgnoreCase("y")) {

                    System.out.println();

                    area = LittleMe.VarCollector(area, "area");

                    radius = Math.sqrt(area / Math.PI);  //using formula, we obtain radius

                    known = "ar"; //known variables are area and radius

                    circleProperties(); //print some known properties of a circle

                } else if (LittleMe.userOption.equalsIgnoreCase("n")) {

                    System.out.println();

                    LittleMe.Message("Perhaps, we should try something else like sector analysis");
                }

                System.out.println(); //for formatting purposes only

                LittleMe.Question("Are you interested in calculating a piece of the circle (Sectors)\n\n"
                        + LittleMe.cSpace() + "OR use this technique to find radius ");

                if (LittleMe.userOption.equalsIgnoreCase("y")) {

                    System.out.println();

                    angles = LittleMe.VarCollector(angles, "angle (degree)");

                    sector = true; //user is interested in sectors

                    System.out.println();

                    LittleMe.varQuest("value", "sector area");

                    if (LittleMe.userOption.equalsIgnoreCase("y")) {
                        //calculate value of radius using sector formmula
                        //print all possible values

                        System.out.println();

                        sectorarea = LittleMe.VarCollector(sectorarea, "sector area");

                        radius = Math.sqrt((360 * sectorarea) / (angles * Math.PI));

                        circleProperties(); //prints the known properties of a cirlce

                    } else if (LittleMe.userOption.equalsIgnoreCase("n")) {

                        System.out.println();

                        LittleMe.varQuest("value", "arc length");

                        if (LittleMe.userOption.equalsIgnoreCase("y")) {

                            System.out.println();

                            arclength = LittleMe.VarCollector(arclength, "arc length"); //collecting information from the user here 

                            radius = (180 * arclength) / (angles * Math.PI);

                            circleProperties(); //prints the known properties of a cirlce

                        } else if (LittleMe.userOption.equalsIgnoreCase("n")) {
                            //cannot help you find the radius, need more information
                            System.out.println();

                            sector = false; // cannot find the required values

                            LittleMe.Message("I cannot find the radius, I don't have enough information"); //user interraction
                        }
                    }

                } else if (LittleMe.userOption.equalsIgnoreCase("n")) {
                    //cannot help you using this information
                    sector = false; //cannot find the required values

                    System.out.println();

                    LittleMe.Message("Okay"); //user interraction
                }
            }

            if (sector == true) {

                circleSectorProperties(); //sector calculation

                sector = false; //reset it back to default
            }

            //ask user if they want to keep the section open
            System.out.println();

            LittleMe.Question("Do you still want to work on more circles?");

            if (LittleMe.userOption.equalsIgnoreCase("y")) {

                System.out.println();
                System.out.println();

            } else if (LittleMe.userOption.equalsIgnoreCase("n")) {

                SectorOpen = false; //closes the section

                System.out.println();
                System.out.println();

                LittleMe.Message("Okay, I will close the section"); //user interraction

            }
        } while (SectorOpen == true); //end the loop for this section of the program
        //close this sector

        //redraw the GUI.
        LittleMe.linebreak();

        LittleMe.printConsole();
    }

    public Circle(boolean GUI) {

        SwingUpdater circle = new SwingUpdater();
        circle.execute();

    }

    public class SwingUpdater extends SwingWorker<Void, String> {

        @Override
        protected Void doInBackground() throws Exception {
            //-----------------------------------------------------------
            known = "A1";  //used for resetting and to prevent null exception

            int n = JOptionPane.showConfirmDialog(null, "Do you know the radius of the circle", "Little Me", JOptionPane.YES_NO_OPTION);

            if (n == JOptionPane.YES_OPTION) {

                boolean correct = false;

                do {

                    try {
                        radius = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter the known radius of the circle",
                                "Little Me", JOptionPane.QUESTION_MESSAGE));
                        correct = true;
                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(null, "Invalid Input", "Little Me", JOptionPane.ERROR_MESSAGE);
                    }

                } while (correct == false);

                known = "r";

                startToThink();

                publish("The area of the circle is " + getArea());

                 // for formating purposes only
                startToThink(); //effects and sound

                publish("The circumference of the circle is " + getCircumference());

                 // for formating purposes only
                n = JOptionPane.showConfirmDialog(null, "Are you interested in calculating a piece of the circle (Sectors)"
                        + "", "Little Me", JOptionPane.YES_NO_OPTION);

                if (n == JOptionPane.YES_OPTION) {

                    correct = false;

                    do {

                        try {
                            angles = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter the known angle (degree) of the sector",
                                    "Little Me", JOptionPane.QUESTION_MESSAGE));
                            correct = true;
                        } catch (Exception e) {
                            JOptionPane.showMessageDialog(null, "Invalid Input", "Little Me", JOptionPane.ERROR_MESSAGE);
                        }

                    } while (correct == false);

                    sectorGUI = true; //user is interested in sectors

                } else {

                    publish("Okay"); //user interraction

                }

            } else //DOES NOT KNOW THE RADIUS HERE...TRYING TO FIND IT
            {

                publish("Let's find the radius of the circle");

                 // for formating purposes only
                n = JOptionPane.showConfirmDialog(null, "Do you know the area of the circle"
                        + "", "Little Me", JOptionPane.YES_NO_OPTION);

                if (n == JOptionPane.YES_OPTION) {

                    boolean correct = false;

                    do {

                        try {
                            area = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter the known area of the cirlce",
                                    "Little Me", JOptionPane.QUESTION_MESSAGE));
                            correct = true;
                        } catch (Exception e) {
                            JOptionPane.showMessageDialog(null, "Invalid Input", "Little Me", JOptionPane.ERROR_MESSAGE);
                        }

                    } while (correct == false);

                    radius = Math.sqrt(area / Math.PI);  //using formula, we obtain radius

                    known = "ar"; //known variables are area and radius

                    circleProperties2(); //print some known properties of a circle

                } else {

                    publish("Perhaps, we should try something else like sector analysis");
                }

                 //for formatting purposes only
                n = JOptionPane.showConfirmDialog(null, "Are you interested in calculating a piece of the circle (Sectors)\n\n"
                        + "OR use this technique to find radius ", "Little Me", JOptionPane.YES_NO_OPTION);

                if (n == JOptionPane.YES_OPTION) {

                    boolean correct = false;

                    do {

                        try {
                            angles = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter the known angle (degree) of the sector",
                                    "Little Me", JOptionPane.QUESTION_MESSAGE));
                            correct = true;
                        } catch (Exception e) {
                            JOptionPane.showMessageDialog(null, "Invalid Input", "Little Me", JOptionPane.ERROR_MESSAGE);
                        }

                    } while (correct == false);

                    sectorGUI = true; //user is interested in sectors

                    n = JOptionPane.showConfirmDialog(null, "Do you know the value for the sector area", "Little Me", JOptionPane.YES_NO_OPTION);

                    if (n == JOptionPane.YES_OPTION) {

                        correct = false;

                        do {

                            try {
                                sectorarea = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter the known value for the sector area",
                                        "Little Me", JOptionPane.QUESTION_MESSAGE));
                                correct = true;
                            } catch (Exception e) {
                                JOptionPane.showMessageDialog(null, "Invalid Input", "Little Me", JOptionPane.ERROR_MESSAGE);
                            }

                        } while (correct == false);

                        radius = Math.sqrt((360 * sectorarea) / (angles * Math.PI));

                        circleProperties2(); //prints the known properties of a cirlce

                    } else {

                        n = JOptionPane.showConfirmDialog(null, "Do you know the value for the arc length", "Little Me", JOptionPane.YES_NO_OPTION);

                        if (n == JOptionPane.YES_OPTION) {

                            correct = false;

                            do {

                                try {
                                    arclength = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter the known value for the arc length",
                                            "Little Me", JOptionPane.QUESTION_MESSAGE));
                                    correct = true;
                                } catch (Exception e) {
                                    JOptionPane.showMessageDialog(null, "Invalid Input", "Little Me", JOptionPane.ERROR_MESSAGE);
                                }

                            } while (correct == false);

                            radius = (180 * arclength) / (angles * Math.PI);

                            circleProperties2(); //prints the known properties of a cirlce

                        } else {
                            //cannot help you find the radius, need more information

                            sectorGUI = false; // cannot find the required values

                            publish(""
                                    + "I cannot find the radius, I don't have enough information"); //user interraction
                        }
                    }

                } else {
                    //cannot help you using this information
                    sectorGUI = false; //cannot find the required values

                    publish("Okay"); //user interraction
                }
            }

            if (sectorGUI == true) {
                circleSectorProperties2();
            }

            //------------------------------------------------------------------------
            return null;
        }

        @Override
        protected void process(final List<String> chunks) {
    // Updates the messages text area
    /*for (String string : chunks) {
             SquareGUI.JTextAreaOutput.setText(SquareGUI.JTextAreaOutput.getText() + "\n\n" + string);
             }*/

            // Updates the messages text area
            for (final String string : chunks) {
                CircleGUI.JTextAreaOutput.append(string);
                CircleGUI.JTextAreaOutput.append("\n");

            }
        }

        //this method provides information on sector of a circle
        public final void circleSectorProperties2() {

            startToThink();

            publish("Oh, The area of the sector is " + getSectorArea());

            startToThink();

            publish("The arc length of the sector is " + getArcLength());
        }

        //this method provides information on the whole circle
        public final void circleProperties2() {

            startToThink();

            publish("Oh, The radius of the circle is " + String.format("%.04f", radius));

            startToThink();

            publish("The area of the circle is " + getArea());

            startToThink();

            publish("The circumference of the circle is " + getCircumference());
        }

        public void startToThink() {
            //-----------------------------------------
            currentWord = "\nThinking .";

            publish(currentWord);
            int number; //how long the timer will run
            do {
                number = random.nextInt(4000);
            } while (number <= 3000);

            LittleMe.playsound("calculating.mp3"); //this plays the calculation sound

            Timer t = new Timer(3000, (ActionEvent ae) -> {
                currentWord += currentWord + ".";
                publish(currentWord); //update the current world
            });
            t.start(); //starting the timer here 

            //this causes the thread to sleep again
            try {
                Thread.sleep(number);

            } catch (InterruptedException ex) {

            }
            t.stop(); //stop the timer 
            sound.stop(); //tSystem.out.prihis stops the sound file
            currentWord = "\n"; //to tell the user that computing is done
            publish(currentWord);
            LittleMe.playsound("beep.mp3"); //a sound to say it's done.
        }

    }

    //this method provides information on sector of a circle
    public final void circleSectorProperties() {

        System.out.println(); // for formating purposes only

        LittleMe.Thinking();

        System.out.println(LittleMe.cSpace() + "Oh, The area of the sector is " + getSectorArea());

        System.out.println(); // for formating purposes only

        LittleMe.Thinking();

        System.out.println(LittleMe.cSpace() + "The arc length of the sector is " + getArcLength());

        System.out.println(); // for formating purposes only

    }

    //this method provides information on the whole circle
    public final void circleProperties() {

        //calculating possible values for area and circumference rounded to four decimal places
        System.out.println(); // for formating purposes only

        LittleMe.Thinking();

        System.out.println(LittleMe.cSpace() + "Oh, The radius of the circle is " + String.format("%.04f", radius));

        System.out.println(); // for formating purposes only

        LittleMe.Thinking();

        System.out.println(LittleMe.cSpace() + "The area of the circle is " + getArea());

        System.out.println(); // for formating purposes only

        LittleMe.Thinking();

        System.out.println(LittleMe.cSpace() + "The circumference of the circle is " + getCircumference());

        System.out.println(); // for formating purposes only
    }

    //this method calculates the area of the circle
    public final String getArea() {
        area = Math.PI * radius * radius;

        return String.format("%.04f", area);
    }

    //this method calculates the area of a sector of a circle
    public final String getSectorArea() {
        sectorarea = (angles / 360) * Math.PI * radius * radius;

        return String.format("%.04f", sectorarea);
    }

    //this method calculates the circumference of a circle
    public final String getCircumference() {
        perimeter = 2.0000 * Math.PI * radius;

        return String.format("%.04f", perimeter);
    }

    //this method calculates the length of an arc of a circle
    public final String getArcLength() {
        arclength = (angles / 360) * 2.0000 * Math.PI * radius;

        return String.format("%.04f", arclength);
    }

}
