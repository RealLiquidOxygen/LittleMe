/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package littleme;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JComboBox;
import static littleme.MainApplicationGUI.screenSize;

/**
 *
 * @author owoye001
 */
public class MainApplicationGUIJPanel extends javax.swing.JPanel {

    public static javax.swing.JLabel LblKidName;

    private javax.swing.JButton btnExitButton;
    private javax.swing.JButton btnLittleMe;
    private javax.swing.JButton jButton6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel copyrightLogo;
    
    static LittleMeGameForGUI littleme;

    /**
     * Creates new form MainApplicationGUIJPanel
     */
    public MainApplicationGUIJPanel() {
        initComponents();

        int screenHeight = (int) (screenSize.getHeight());

        int screenWidth = (int) (screenSize.getWidth());

        jPanel1 = new javax.swing.JPanel();
        String[] options = {"Square", "Rectangle", "Triangle", "Trapezium", "Cylinder", "Circle"};
        JComboBox Options = new JComboBox(options);

        ActionListener OptionsActionListener = (ActionEvent ae) -> {
            //disable game if another option is selected
            LittleMeGameGUI.btnRestart.setEnabled(true); //oll
            
            LittleMeGameGUI.JTextAreaOutput.setText(""); //Empty the box out
            
            switch (Options.getSelectedItem().toString()) {
                
                case "Square":
                    DisplaySquare(); //displays square 
                    break;
                case "Triangle":
                    DisplayTriangle();
                    break;
                case "Rectangle":
                    DisplayRectangle(); //displays rectangle
                    break;
                case "Trapezium":
                    DisplayTrapezium(); //displays trapezium

                    break;
                case "Cylinder":
                    DisplayCylinder(); //displays cylinder
                    break;
                case "Circle":
                    DisplayCircle(); //displays circle
                    break;
            }
        };
        Options.addActionListener(OptionsActionListener);
        jPanel1.add(Options, new org.netbeans.lib.awtextra.AbsoluteConstraints(20 * screenWidth / 1368, 20 * screenHeight / 768, 200 * screenWidth / 1368, 50 * screenHeight / 768));

        btnExitButton = new javax.swing.JButton();
        btnLittleMe = new javax.swing.JButton();

        jButton6 = new javax.swing.JButton();
        LblKidName = new javax.swing.JLabel();
        copyrightLogo = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 204, 204));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnExitButton.setBackground(new java.awt.Color(255, 255, 255));
        btnExitButton.setText("Exit");
        btnExitButton.addActionListener((java.awt.event.ActionEvent evt) -> {
            btnExitButtonActionPerformed(evt);
        });
        jPanel1.add(btnExitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(20 * screenWidth / 1368, 190 * screenHeight / 768, 90 * screenWidth / 1368, 50 * screenHeight / 768));

        btnLittleMe.setText("Little Me");
        btnLittleMe.addActionListener((java.awt.event.ActionEvent evt) -> {
            btnLittleMeActionPerformed(evt);
        });
        jPanel1.add(btnLittleMe, new org.netbeans.lib.awtextra.AbsoluteConstraints(20 * screenWidth / 1368, 70 * screenHeight / 768, 190 * screenWidth / 1368, 50 * screenHeight / 768));

        jButton6.setText("Help/About");
        jButton6.addActionListener((java.awt.event.ActionEvent evt) -> {
            jButton6ActionPerformed(evt);
        });
        jPanel1.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20 * screenWidth / 1368, 130 * screenHeight / 768, 130 * screenWidth / 1368, 50 * screenHeight / 768));

        LblKidName.setFont(new java.awt.Font("BatangChe", 2, 22)); // NOI18N
        copyrightLogo.setFont(new java.awt.Font("BatangChe", 2, 18));
        copyrightLogo.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        LblKidName.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        copyrightLogo.setText("Copyright (c) 2016 Big-Me");

        jPanel1.add(LblKidName, new org.netbeans.lib.awtextra.AbsoluteConstraints(290 * screenWidth / 1368, 20 * screenHeight / 768, 160 * screenWidth / 1368, 40 * screenHeight / 768));
        jPanel1.add(copyrightLogo, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000 * screenWidth / 1368, 673 * screenHeight / 768, 270 * screenWidth / 1368, 30 * screenHeight / 768));

        jPanel1.add(Options, new org.netbeans.lib.awtextra.AbsoluteConstraints(20 * screenWidth / 1368, 20 * screenHeight / 768, 250 * screenWidth / 1368, 40 * screenHeight / 768));

        add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, screenWidth - 40, screenHeight - 40));

    }

    private void btnSquareActionPerformed(java.awt.event.ActionEvent evt) {

        // playsound("herewego.mp3"); //plays sound
    }

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {
        LittleMe.AboutHelpProgram2(); //show help and about
    }

    private void btnCylinderActionPerformed(java.awt.event.ActionEvent evt) {
        // playsound("herewego.mp3"); //plays sound

    }

    private void btnTrapeziumActionPerformed(java.awt.event.ActionEvent evt) {
        // playsound("herewego.mp3"); //plays sound
        DisplayTrapezium(); //displays trapezium
    }

    private void btnCircleActionPerformed(java.awt.event.ActionEvent evt) {

        // playsound("herewego.mp3"); //plays sound
        DisplayCircle(); //displays circle
    }

    private void btnRectangleActionPerformed(java.awt.event.ActionEvent evt) {

        // playsound("herewego.mp3"); //plays sound
        DisplayRectangle(); //displays rectangle
    }

    private void btnTriangleActionPerformed(java.awt.event.ActionEvent evt) {
        // playsound("herewego.mp3"); //plays sound
        DisplayTriangle(); //displays triangle
    }

    private void btnLittleMeActionPerformed(java.awt.event.ActionEvent evt) {
        DisplayLittleMe();
    }

    private void btnExitButtonActionPerformed(java.awt.event.ActionEvent evt) {
        // TODO add your handling code here:
        System.exit(0);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setBackground(new java.awt.Color(255, 204, 204));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
    private void DisplaySquare() {
        MainApplicationGUI.cardLayout.show(MainApplicationGUI.mainPanel, "2"); //Selecting the card to be shown
    }

    private void DisplayRectangle() {
        MainApplicationGUI.cardLayout.show(MainApplicationGUI.mainPanel, "3"); //Selecting the card to be shown
    }

    private void DisplayCircle() {
        MainApplicationGUI.cardLayout.show(MainApplicationGUI.mainPanel, "6"); //Selecting the card to be shown

    }

    private void DisplayTriangle() {
        MainApplicationGUI.cardLayout.show(MainApplicationGUI.mainPanel, "5"); //Selecting the card to be shown
    }

    private void DisplayTrapezium() {
        MainApplicationGUI.cardLayout.show(MainApplicationGUI.mainPanel, "4"); //Selecting the card to be shown
    }

    private void DisplayCylinder() {
        MainApplicationGUI.cardLayout.show(MainApplicationGUI.mainPanel, "9"); //Selecting the card to be shown
    }

    private void DisplayLittleMe() {
        MainApplicationGUI.cardLayout.show(MainApplicationGUI.mainPanel, "7"); //Selecting the card to be shown
        littleme = new LittleMeGameForGUI(); //create game
    }
}
