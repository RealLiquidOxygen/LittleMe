/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package littleme;

import java.awt.event.ActionEvent;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.SwingWorker;
import javax.swing.Timer;
import static littleme.LittleMe.random;
import static littleme.LittleMe.sound;
import static littleme.Square.currentWord;

/**
 *
 * @author owoye001
 */
//this class say what it means to be a cylinder
public class Cylinders {

    double area; //the surface area of side of the cylinder

    double volume; //the volume of the cylinder

    double radius; // the length of the radius

    double height; // the perpendicular height

    String known; //to determine the known values....in case of equation solving ..

    Boolean SectorOpen;  //to determine whether the loop for this section keep runnning.

    public Cylinders() {

        SectorOpen = true; //the loop is set to run until it is stopped by the user. 

        do {

            known = "A1";  //used for resetting and to prevent null exception

            LittleMe.varQuest("radius", "cylinder");

            if (LittleMe.userOption.equalsIgnoreCase("y")) {

                System.out.println(); // for formating purposes only

                radius = LittleMe.VarCollector(radius, "radius");

                known = "R"; //known variables.

                System.out.println();

                LittleMe.varQuest("height", "cylinder"); //this asks a question 

                if (LittleMe.userOption.equalsIgnoreCase("y")) {

                    System.out.println(); // for formating purposes only

                    height = LittleMe.VarCollector(height, "height");

                    known = "RH"; //known variables.

                    System.out.println();

                //PRINT OUT THE ANSWERS
                } else if (LittleMe.userOption.equalsIgnoreCase("n")) {

                    System.out.println();

                    LittleMe.InfoS("I have been thinking....Not enough information to calculate anything about this shape");

                }

            } else if (LittleMe.userOption.equalsIgnoreCase("n")) {

                System.out.println();

                LittleMe.InfoS("I have been thinking....Not enough information to calculate anything about this shape");

            }

            //print out the result
            //this print out the required answers
            if (known.equalsIgnoreCase("RH")) {

                System.out.println(); // for formating purposes only

                LittleMe.Thinking();

                System.out.println(LittleMe.cSpace() + "The side surface area of the cyldiner is " + getArea());

                System.out.println(); // for formating purposes only

                LittleMe.Thinking();

                System.out.println(LittleMe.cSpace() + "The volume of the cylinder is " + getVolume());

                System.out.println(); // for formating purposes only

            }

            //ask user if they want to keep the section open
            System.out.println();

            LittleMe.Question("Do you still want to work on more cylinders?");

            if (LittleMe.userOption.equalsIgnoreCase("y")) {

                System.out.println();
                System.out.println();

            } else if (LittleMe.userOption.equalsIgnoreCase("n")) {

                SectorOpen = false; //closes the section

                System.out.println();
                System.out.println();

                LittleMe.Message("Okay, I will close the section"); //user interraction

            }

        } while (SectorOpen == true); //end of do loop   

    //redraw the GUI.
        LittleMe.linebreak();

        LittleMe.printConsole();
    }
    //calculate the side surface area of the cylinder

    public Cylinders(boolean GUI) {

        SwingUpdater cylinders = new SwingUpdater();
        cylinders.execute(); //execute the swing worker
    }
    //calculate the side surface area of the cylinder

    public class SwingUpdater extends SwingWorker<Void, String> {

        @Override
        protected Void doInBackground() throws Exception {
            //-----------------------------------------------------------
            known = "A1";  //used for resetting and to prevent null exception

            int n = JOptionPane.showConfirmDialog(null, "Do you know radius of the cylinder", "Little Me", JOptionPane.YES_NO_OPTION);

            if (n == JOptionPane.YES_OPTION) {

                boolean correct = false;

                do {

                    try {
                        radius = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter the value of the known radius of the cylinder",
                                "Little Me", JOptionPane.QUESTION_MESSAGE));
                        correct = true;
                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(null, "Invalid Input", "Little Me", JOptionPane.ERROR_MESSAGE);
                    }

                } while (correct == false);

                known = "R"; //known variables.

                n = JOptionPane.showConfirmDialog(null, "Do you know height of the cylinder", "Little Me", JOptionPane.YES_NO_OPTION);

                if (n == JOptionPane.YES_OPTION) {

                    correct = false;

                    do {

                        try {
                            height = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter the value of the known height of the cylinder",
                                    "Little Me", JOptionPane.QUESTION_MESSAGE));
                            correct = true;
                        } catch (Exception e) {
                            JOptionPane.showMessageDialog(null, "Invalid Input", "Little Me", JOptionPane.ERROR_MESSAGE);
                        }

                    } while (correct == false);

                    known = "RH"; //known variables.

                //PRINT OUT THE ANSWERS
                } else {

                    publish("I have been thinking....Not enough information to calculate anything about this shape");

                }

            } else {

                publish("I have been thinking....Not enough information to calculate anything about this shape");

            }

            //print out the result
            //this print out the required answers
            if (known.equalsIgnoreCase("RH")) {

                startToThink();

                publish("The side surface area of the cyldiner is " + getArea());

                startToThink();

                publish("The volume of the cylinder is " + getVolume());

            }

            //------------------------------------------------------------------------
            return null;
        }

        public void startToThink() {
            //-----------------------------------------
            currentWord = "\nThinking .";

            publish(currentWord);
            int number; //how long the timer will run
            do {
                number = random.nextInt(4000);
            } while (number <= 3000);

            LittleMe.playsound("calculating.mp3"); //this plays the calculation sound

            Timer t = new Timer(3000, (ActionEvent ae) -> {
                currentWord += currentWord + ".";
                publish(currentWord); //update the current world
            });
            t.start(); //starting the timer here 

            //this causes the thread to sleep again
            try {
                Thread.sleep(number);

            } catch (InterruptedException ex) {

            }
            t.stop(); //stop the timer 
            sound.stop(); //tSystem.out.prihis stops the sound file
            currentWord = "\n"; //to tell the user that computing is done
            publish(currentWord);
            LittleMe.playsound("beep.mp3"); //a sound to say it's done.
        }

        @Override
        protected void process(final List<String> chunks) {
    // Updates the messages text area
    /*for (String string : chunks) {
             SquareGUI.JTextAreaOutput.setText(SquareGUI.JTextAreaOutput.getText() + "\n\n" + string);
             }*/

            // Updates the messages text area
            for (final String string : chunks) {
                CylinderGUI.JTextAreaOutput.append(string);
                CylinderGUI.JTextAreaOutput.append("\n");

            }
        }

    }

    public final String getArea() {

         //	2 × pi × radius × heigh   surface area of sides
        area = 2.0000 * Math.PI * radius * height;

        return String.format("%.04f", area);

    }

    //calculates the  volume
    public final String getVolume() {

         //volume of a cylinder der	pi × radius2 × height
        volume = Math.PI * radius * radius * height;

        return String.format("%.04f", volume);

    }

    //thinking
}
