/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package littleme;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.SwingWorker;
import javax.swing.Timer;
import static littleme.LittleMe.random;
import static littleme.LittleMe.sound;

/**
 *
 * @author owoye001
 */
//this class states the properties of square
public class Square {

    double area; //the area of the square

    double length; //length of one side of the square

    static String currentWord = ""; //current word painted

    private boolean SectionOpen = true; //determines whether the section should be kept open for other other operations

    //constructor
    public Square() {

        do {

            LittleMe.Question("Do you know the length of one side of the square");

            if (LittleMe.userOption.equalsIgnoreCase("y")) {

                System.out.println(); //for formating purposes

                length = LittleMe.VarCollector(length, "length"); //for collecting area and interracting with user

                System.out.println();

                LittleMe.Thinking(); //thinking

                System.out.println(LittleMe.cSpace() + "The area of the square is " + getArea());

                System.out.println(); // for formating purposes only

            } else if (LittleMe.userOption.equalsIgnoreCase("n")) {

                System.out.println();

                LittleMe.Question("Do you know the area of the square");

                if (LittleMe.userOption.equalsIgnoreCase("y")) {

                    System.out.println();

                    area = LittleMe.VarCollector(area, "area"); //collecting required values from the user in a pleasant manner.

                    //this produces the answer
                    System.out.println(); // for formating purposes only

                    LittleMe.Thinking();

                    System.out.println(LittleMe.cSpace() + "The length of one side of the square is " + getLength());

                    System.out.println(); // for formating purposes only

                } else if (LittleMe.userOption.equalsIgnoreCase("n")) {

                    System.out.println();

                    LittleMe.InfoS("I am sorry, I cannot help you with this problem");
                }
            }

            //ask user if they want to keep the section open
            System.out.println();

            LittleMe.Question("Do you still want to work on more squares?");

            if (LittleMe.userOption.equalsIgnoreCase("y")) {

                System.out.println();  //for formatting purposes only
                System.out.println();

            } else if (LittleMe.userOption.equalsIgnoreCase("n")) {

                SectionOpen = false; //closes the section

                System.out.println(); //for formatting purposes only
                System.out.println();

                LittleMe.Message("Okay, I will close the section"); //user interraction

            }

        } while (SectionOpen == true); //end loop for this section.

        //this closes this section
        LittleMe.nextSection();

        LittleMe.printConsole(); //prints the console 

    }

    //constructor  FOR GUI 
    public Square(boolean GUI) {

        //nothing here. planning to call swing worker
        SwingUpdater square = new SwingUpdater();
        square.execute(); //execute

    }

    public class SwingUpdater extends SwingWorker<Void, String> {

        @Override
        protected Void doInBackground() throws Exception {
            //-----------------------------------------------------------
            int n = JOptionPane.showConfirmDialog(null, "Do you know the length of one side of the square", "Little Me",
                    JOptionPane.YES_NO_OPTION); //asking a question here 

            boolean Correct = false;  //answer is not correct 

            if (n == JOptionPane.YES_OPTION) {

                do {
                    try {
                        length = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter the value for the known length", "Little Me", JOptionPane.QUESTION_MESSAGE)); //for collecting area and interracting with user

                        Correct = true;  //the value is appropriate  
                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(null, "Invalid  Value", "Little Me", JOptionPane.INFORMATION_MESSAGE); // display error message to user
                    }
                } while (Correct == false); //answer validation done here 

                startToThink(); //start thinking here. 

                publish("The area of the square is " + getArea());

            } else {

                n = JOptionPane.showConfirmDialog(null, "Do you know the area the square", "Little Me",
                        JOptionPane.YES_NO_OPTION); //asking a question here 
                if (n == JOptionPane.YES_OPTION) {

                    Correct = false;  //answer is not correct 
                    do {
                        try {
                            area = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter the value for the known area", "Little Me", JOptionPane.QUESTION_MESSAGE)); //for collecting area and interracting with user

                            Correct = true;  //the value is appropriate  
                        } catch (Exception e) {
                            JOptionPane.showMessageDialog(null, "Invalid  Value", "Little Me", JOptionPane.INFORMATION_MESSAGE); // display error message to user
                        }
                    } while (Correct == false); //answer validation done here 

                    startToThink(); //the method start thinking here. 

                    publish("The length of one side the square is " + getLength());

                } else {

                    publish("I am sorry, I cannot help you with this problem");

                }
            }

        //ask user if they want to keep the section open
            //------------------------------------------------------------------------
            return null;
        }

        public void startToThink() {
            //-----------------------------------------
            currentWord = "\nThinking .";

            publish(currentWord);
            int number; //how long the timer will run
            do {
                number = random.nextInt(4000);
            } while (number <= 3000);

            LittleMe.playsound("calculating.mp3"); //this plays the calculation sound

            Timer t = new Timer(3000, (ActionEvent ae) -> {
                currentWord += currentWord + ".";
                publish(currentWord); //update the current world
            });
            t.start(); //starting the timer here 

            //this causes the thread to sleep again
            try {
                Thread.sleep(number);

            } catch (InterruptedException ex) {

            }
            t.stop(); //stop the timer 
            sound.stop(); //tSystem.out.prihis stops the sound file
            currentWord = "\n"; //to tell the user that computing is done
            publish(currentWord);
            LittleMe.playsound("beep.mp3"); //a sound to say it's done.
        }

        @Override
        protected void process(final List<String> chunks) {
    // Updates the messages text area
    /*for (String string : chunks) {
             SquareGUI.JTextAreaOutput.setText(SquareGUI.JTextAreaOutput.getText() + "\n\n" + string);
             }*/

            // Updates the messages text area
            for (final String string : chunks) {
                SquareGUI.JTextAreaOutput.append(string);
                SquareGUI.JTextAreaOutput.append("\n");

            }
        }

    }

    //gets the area of the squares
    public final double getArea() {
        area = length * length;

        return area;
    }

    //get the length of one side of square
    public final String getLength() {
        length = Math.sqrt(area);

        return String.format("%.04f", length);
    }
}
