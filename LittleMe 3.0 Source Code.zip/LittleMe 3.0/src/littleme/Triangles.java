/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package littleme;

import java.awt.event.ActionEvent;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.SwingWorker;
import javax.swing.Timer;
import static littleme.LittleMe.random;
import static littleme.LittleMe.sound;
import static littleme.Square.currentWord;

/**
 *
 * @author owoye001
 */
//this class embodies what it means to be a triangle
class Triangles {

    double area; //the area of the square

    double length1; //length of one side of the triangle

    double length2; //length of another sides of the triangle

    double length3; //length of another sides of the triangle

    double perimeter; //perimeter of the triangle

    double height; //perpendicular height of a triangle lying on its base. 

    String known; //to determine the known values....in case of equation solving ..

    Boolean SectorOpen;  //to determine whether the loop for this section keep runnning. 

    public Triangles() {

        SectorOpen = true; //the loop is set to run until it is stopped by the user. It determines whether this section is open

        do {

            known = "A1";  //used for resetting and to prevent null exception

            LittleMe.varQuest("length of one side", "triangle"); //this asks a question and verifies that input that user enters

            if (LittleMe.userOption.equalsIgnoreCase("y")) { //if the user knowns the length of one side of the triangle

                length1 = LittleMe.VarCollector(length1, "length (first side)");

                known = "L1"; //this is just for me to know what variable i have collected from the user

                System.out.println(); //this is for formatting purpose only

                LittleMe.varQuest("length of another side", "triangle"); //asks a yes or no question, about whether the user known the length of another side of the triangle

                if (LittleMe.userOption.equalsIgnoreCase("y")) { //if the user says yes 

                    System.out.println(); //for formatting purposes only 

                    length2 = LittleMe.VarCollector(length2, "length (second side)"); //this method will actually collect the value

                    known = "L1L2"; // known variables...this is to help me known how much information I have collected 

                    System.out.println(); // for formatting purpose only 

                    LittleMe.varQuest("length of another side", "triangle"); //asks a yes or no question 

                    if (LittleMe.userOption.equalsIgnoreCase("y")) { // if user answers yes to the question 

                        System.out.println(); //for formatting purposes only 

                        length3 = LittleMe.VarCollector(length3, "length (third side)");

                        known = "L1L2L3"; // known variables

                        //PRINT PERIMETER AND AREA. 
                    } else if (LittleMe.userOption.equalsIgnoreCase("n")) { // if the user answers no to the user

                        System.out.println(); // for formatting purpose only 

                        LittleMe.InfoS("I have been thinking.... Let try another approach"); //print out an information to the user 
                    }
                } else if (LittleMe.userOption.equalsIgnoreCase("n")) { //if user say no to a question 
                    System.out.println();

                    LittleMe.InfoS("I have been thinking.... Let try another approach"); //output a message to the user 
                }
            } else if (LittleMe.userOption.equalsIgnoreCase("n")) {
                System.out.println();

                LittleMe.InfoS("I have been thinking.... Let try another approach");
            }

            //the other approach to solving areas. Here I am collecting variables
            if (known.equalsIgnoreCase("A2") || known.equalsIgnoreCase("L1") || known.equalsIgnoreCase("L1L2")) { //checks for known variables and decides what to do next 

                System.out.println(); // for formatting purpose only 

                LittleMe.varQuest("base", "triangle"); //asks a question about the length of the base of the triangle

                if (LittleMe.userOption.equalsIgnoreCase("y")) { //if user known the values  (yes or no) question 

                    length1 = LittleMe.VarCollector(length1, "base"); // collects the known value from the user (with error checking)

                    known = "B"; //this is just to help me keep track of how much information I have collected from the user

                    System.out.println(); //for formatting purpose only

                    LittleMe.varQuest("length of the perpendicular height", "triangle"); //asking a question here 

                    if (LittleMe.userOption.equalsIgnoreCase("y")) {

                        System.out.println();

                        height = LittleMe.VarCollector(height, "height"); //collecting more information here 

                        known = "BH"; // known variables length and area

                        //print out the area
                    } else if (LittleMe.userOption.equalsIgnoreCase("n")) { //if user say no to a question 

                        System.out.println(); // for formatting purpose only 

                        LittleMe.InfoS("I am sorry, I cannot help you with this problem. Not enough information"); //outputs information to the user
                    }

                } else if (LittleMe.userOption.equalsIgnoreCase("n")) { //user say no 

                    System.out.println();

                    LittleMe.InfoS("I am sorry, I cannot help you with this problem. Not enough information");
                }

            }

            //this print out the required answers
            if (known.equalsIgnoreCase("L1L2L3")) {
                //this produces the answer
                System.out.println(); // for formating purposes only

                LittleMe.Thinking(); //to show the computer is thinking about the input. For dramatic effects 

                System.out.println(LittleMe.cSpace() + "Using Herons Formula, the area of the triangle is " + getAreaSSS());

                System.out.println(); // for formating purposes only

                LittleMe.Thinking(); // to show the computer is thinking about the input. For dramatic effects 

                System.out.println(LittleMe.cSpace() + "The perimeter of the triangle is " + getPerimeter());

                System.out.println(); // for formating purposes only
            }
            if (known.equalsIgnoreCase("BH")) {
                //this produces the answer
                System.out.println(); // for formating purposes only

                LittleMe.Thinking();

                System.out.println(LittleMe.cSpace() + "Using half base time height, the area of the triangle is " + getAreaSH());

                System.out.println(); // for formating purposes only

                LittleMe.Thinking();

                System.out.println(LittleMe.cSpace() + "Perimeter of the triangle is not computed using this method");

                System.out.println(); // for formating purposes only
            }

            //ask user if they want to keep the section open
            System.out.println();

            LittleMe.Question("Do you still want to work on more triangles?");

            if (LittleMe.userOption.equalsIgnoreCase("y")) {

                System.out.println();
                System.out.println();

            } else if (LittleMe.userOption.equalsIgnoreCase("n")) {

                SectorOpen = false; //closes the section

                System.out.println();
                System.out.println();

                LittleMe.Message("Okay, I will close the section"); //user interraction

            }

        } while (SectorOpen == true); //ends the loop for this section of the program

        //redraw the GUI.
        LittleMe.linebreak();

        LittleMe.printConsole();
    }

    public Triangles(boolean GUI) {

        SwingUpdater triangles = new SwingUpdater();
        triangles.execute(); //execute the task
    }

    public class SwingUpdater extends SwingWorker<Void, String> {

        @Override
        protected Void doInBackground() throws Exception {
            //-----------------------------------------------------------
            known = "A1";  //used for resetting and to prevent null exception

            int n = JOptionPane.showConfirmDialog(null, "Do you know the length of one side of the triangle", "Little Me", JOptionPane.YES_NO_OPTION);

            if (n == JOptionPane.YES_OPTION) {

                boolean correct = false;

                do {

                    try {
                        length1 = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter the known length (first side) of the triangle",
                                "Little Me", JOptionPane.QUESTION_MESSAGE));
                        correct = true;
                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(null, "Invalid Input", "Little Me", JOptionPane.ERROR_MESSAGE);
                    }

                } while (correct == false);

                known = "L1"; //this is just for me to know what variable i have collected from the user

                n = JOptionPane.showConfirmDialog(null, "Do you know the length of another side of the triangle", "Little Me", JOptionPane.YES_NO_OPTION);

                if (n == JOptionPane.YES_OPTION) {

                    correct = false;

                    do {

                        try {
                            length2 = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter the known length (second side) of the triangle",
                                    "Little Me", JOptionPane.QUESTION_MESSAGE));
                            correct = true;
                        } catch (Exception e) {
                            JOptionPane.showMessageDialog(null, "Invalid Input", "Little Me", JOptionPane.ERROR_MESSAGE);
                        }

                    } while (correct == false);

                    known = "L1L2"; // known variables...this is to help me known how much information I have collected 

                    n = JOptionPane.showConfirmDialog(null, "Do you know the length of another side of the triangle", "Little Me", JOptionPane.YES_NO_OPTION);

                    if (n == JOptionPane.YES_OPTION) {

                        correct = false;

                        do {

                            try {
                                length3 = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter the known length (third side) of the triangle",
                                        "Little Me", JOptionPane.QUESTION_MESSAGE));
                                correct = true;
                            } catch (Exception e) {
                                JOptionPane.showMessageDialog(null, "Invalid Input", "Little Me", JOptionPane.ERROR_MESSAGE);
                            }

                        } while (correct == false);

                        known = "L1L2L3"; // known variables

                        //PRINT PERIMETER AND AREA. 
                    } else { // if the user answers no to the user

                        publish("I have been thinking.... Let try another approach"); //print out an information to the user 
                    }
                } else { //if user say no to a question 

                    publish("I have been thinking.... Let try another approach"); //output a message to the user 
                }
            } else {
                System.out.println();

                publish("I have been thinking.... Let try another approach");
            }

            //the other approach to solving areas. Here I am collecting variables
            if (known.equalsIgnoreCase("A2") || known.equalsIgnoreCase("L1") || known.equalsIgnoreCase("L1L2")) { //checks for known variables and decides what to do next 

                n = JOptionPane.showConfirmDialog(null, "Do you know the base of the triangle"
                        + "", "Little Me", JOptionPane.YES_NO_OPTION);

                if (n == JOptionPane.YES_OPTION) {

                    boolean correct = false;

                    do {

                        try {
                            length1 = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter the known base of the triangle",
                                    "Little Me", JOptionPane.QUESTION_MESSAGE));
                            correct = true;
                        } catch (Exception e) {
                            JOptionPane.showMessageDialog(null, "Invalid Input", "Little Me", JOptionPane.ERROR_MESSAGE);
                        }

                    } while (correct == false);

                    known = "B"; //this is just to help me keep track of how much information I have collected from the user

                    n = JOptionPane.showConfirmDialog(null, "Do you know the length of the perpendicular height of the triangle"
                            + "", "Little Me", JOptionPane.YES_NO_OPTION);

                    if (n == JOptionPane.YES_OPTION) {

                        correct = false;

                        do {

                            try {
                                height = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter the known height of the triangle",
                                        "Little Me", JOptionPane.QUESTION_MESSAGE));
                                correct = true;
                            } catch (Exception e) {
                                JOptionPane.showMessageDialog(null, "Invalid Input", "Little Me", JOptionPane.ERROR_MESSAGE);
                            }

                        } while (correct == false);

                        known = "BH"; // known variables length and area

                        //print out the area
                    } else { //if user say no to a question 

                        publish("I am sorry, I cannot help you with this problem. Not enough information"); //outputs information to the user
                    }

                } else { //user say no 

                    publish("I am sorry, I cannot help you with this problem. Not enough information");
                }

            }

            //this print out the required answers
            if (known.equalsIgnoreCase("L1L2L3")) {
                //this produces the answer
                startToThink(); //to show the computer is thinking about the input. For dramatic effects 

                publish("Using Herons Formula, the area of the triangle is " + getAreaSSS());

                startToThink(); // to show the computer is thinking about the input. For dramatic effects 

                publish("The perimeter of the triangle is " + getPerimeter());

            }
            if (known.equalsIgnoreCase("BH")) {
                //this produces the answer
                startToThink();

                publish("Using half base time height, the area of the triangle is " + getAreaSH());

                startToThink();

                publish("Perimeter of the triangle is not computed using this method");

            }

            //------------------------------------------------------------------------
            return null;
        }

        public void startToThink() {
            //-----------------------------------------
            currentWord = "\nThinking .";

            publish(currentWord);
            int number; //how long the timer will run
            do {
                number = random.nextInt(4000);
            } while (number <= 3000);

            LittleMe.playsound("calculating.mp3"); //this plays the calculation sound

            Timer t = new Timer(3000, (ActionEvent ae) -> {
                currentWord += currentWord + ".";
                publish(currentWord); //update the current world
            });
            t.start(); //starting the timer here 

            //this causes the thread to sleep again
            try {
                Thread.sleep(number);

            } catch (InterruptedException ex) {

            }
            t.stop(); //stop the timer 
            sound.stop(); //tSystem.out.prihis stops the sound file
            currentWord = "\n"; //to tell the user that computing is done
            publish(currentWord);
            LittleMe.playsound("beep.mp3"); //a sound to say it's done.
        }

        @Override
        protected void process(final List<String> chunks) {
    // Updates the messages text area
    /*for (String string : chunks) {
             SquareGUI.JTextAreaOutput.setText(SquareGUI.JTextAreaOutput.getText() + "\n\n" + string);
             }*/

            // Updates the messages text area
            for (final String string : chunks) {
                TriangleGUI.JTextAreaOutput.append(string);
                TriangleGUI.JTextAreaOutput.append("\n");

            }
        }

    }

    //calculates the ares
    public final String getAreaSSS() {
        //using heron's formula

        double s = 0.5000 * (length1 + length2 + length3);

        area = Math.sqrt(s * (s - length1) * (s - length2) * (s - length3));

        return String.format("%.04f", area);

    }

    //calculate the area of the triangle using base x perpendicular height.
    public final String getAreaSH() {
        //using 1/2 base * height

        area = 0.5000 * length1 * height;

        return String.format("%.04f", area);

    }

    //calculates the perimeter
    public final String getPerimeter() {
        perimeter = length1 + length2 + length3;

        return String.format("%.04f", perimeter);

    }

}
