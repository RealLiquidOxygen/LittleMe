/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/*
 NAME: AYODELE OWOYELE
 COURSE: INTRODUCTION TO PROGRAMMING II
 DATE: 2/18/2016
 PROGRAM FUNCTIONALITY: THIS PROGRAM HELPS A LITTLE KID WITH HER MATH HOME WORK ASSIGNMENTS. 
 IT ALSO HAS A LITTLE GAME, IN CASE OF BREAKS.
 */
package littleme;

//download the jaco mp3 player jar file from the address below...It is not mine.
//http://jacomp3player.sourceforge.net/
//imported the jaco files here
import java.util.Scanner;
import jaco.mp3.player.MP3Player;
import java.awt.event.ActionEvent;
import java.io.File;
import java.security.SecureRandom;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

/**
 *
 * @author owoye001
 */
public class LittleMe {

    /**
     * @param args the command line arguments
     */
    //Initializations
    static JOptionPane communicateUser = new JOptionPane(); //variable for interactino

    static String kidName; //to records the kids name for more friendlier interactions

    static String userOption; //to collect decided inputs about yes or no

    public static int userChoice; // to store user selection from the console

    static Scanner input; //scanner class declaration

    static Boolean FirstRun = true; //To check whether this is the first time the main loop for the program is running. 

    public static Boolean KeepRunning = true; //Determines whether the program keeps running

    public static SecureRandom random = new SecureRandom(); //generates random number

    public static MP3Player sound; //play mp3 sounds

    //effects and sonds method. method overloading
    static void Thinking(String string, int time) {
        int number; //it is going to end being a random number
        do {
            number = random.nextInt(time);
        } while (number <= time - 3000); //ensures it is just 3 second variation of time..if time is 4 second...then interval will be between 1-4 second
        System.out.println(); //for formating purposes only 
        LittleMe.cPrint(string + " .");

        //creating a timer object here to print out .......
        Timer t = new Timer(100, (ActionEvent ae) -> {
            System.out.print(".");
        });
        t.start(); //this starts the timer

        LittleMe.playsound("calculating.mp3"); //this calls a method that plays a sound 

        //this causes the thread to sleep...just for dramatic effect
        try {
            Thread.sleep(number); //this causes the thread to sleep 
        } catch (InterruptedException ex) {
            //Logger.getLogger(Circle.class.getName()).log(Level.SEVERE, null, ex);
        }
        t.stop(); //this stops the timer after the sleep event hopefully
        sound.stop(); //this stops the sound file
        System.out.print(" done"); //to tell the user that computing is done 
        LittleMe.playsound("beep.mp3"); //a sound to say it's done.
        System.out.println(); //for formating purposes only 
        System.out.println(); //for formating purposes only
        System.out.println(); //for formating purposes only
    }

    //effects and sounds method. method overloading
    static void Thinking(String string) {
        int number; //it is going to end being a random number
        do {
            number = random.nextInt(4000);
        } while (number <= 3000);
        System.out.println(); //for formating purposes only 
        LittleMe.cPrint(string + " .");
        Timer t = new Timer(100, (ActionEvent ae) -> {
            System.out.print(".");
        });
        t.start(); //this starts the timer 
        LittleMe.playsound("calculating.mp3");
        try {
            Thread.sleep(number);
        } catch (InterruptedException ex) {
            //Logger.getLogger(Circle.class.getName()).log(Level.SEVERE, null, ex);
        }
        t.stop(); //this stops the timer after the sleep event hopefully
        sound.stop(); //this stops the sound file
        System.out.print(" done"); //to tell the user that computing is done 
        LittleMe.playsound("beep.mp3"); //a sound to say it's done.
        System.out.println(); //for formating purposes only 
        System.out.println(); //for formating purposes only
        System.out.println(); //for formating purposes only
    }

    //effects and sonds method.
    static void Thinking() {
        int number; //it is going to end being a random number

        //this loop ensures that thinknig time is between 3-4 seconds
        do {
            number = random.nextInt(4000);
        } while (number <= 3000);

        System.out.println(); //for formating purposes only 

        LittleMe.cPrint("Thinking ."); //just prints the word Thinking, but centralized

        //creates a timer object that prints out the dot
        Timer t = new Timer(100, (ActionEvent ae) -> {
            System.out.print(".");
        });
        t.start(); //this starts the timer 

        LittleMe.playsound("calculating.mp3"); //this plays the calculation sound

        //this causes the thread to sleep again
        try {
            Thread.sleep(number);
        } catch (InterruptedException ex) {
            //Logger.getLogger(Circle.class.getName()).log(Level.SEVERE, null, ex);
        }
        t.stop(); //this stops the timer after the sleep event hopefully
        sound.stop(); //this stops the sound file
        System.out.print(" done"); //to tell the user that computing is done 
        LittleMe.playsound("beep.mp3"); //a sound to say it's done.
        System.out.println(); //for formating purposes only 
        System.out.println(); //for formating purposes only
        System.out.println(); //for formating purposes only
    }

    //effects and sonds method. GUI METHOD
//displays the help page and the about page...
    private static void AboutHelpProgram() {

        System.out.println();

        System.out.println();
        nextSection();
        cPrintHeader("*                         *         HELP          *                             *");
        nextSection();

        cPrintHeader("Press a number to make your selection and then press enter");

        System.out.println();

        cPrintHeader("As for LittleMe game, it is a math game developed for kids. Other information is");

        System.out.println();

        cPrintHeader("explained in program boot up.");

        System.out.println();
        nextSection();
        cPrintHeader("*                         *        ABOUT          *                             *");
        nextSection();

        cPrintHeader("This program is written by Ayodele Owoyele. ");

        System.out.println();

        cPrintHeader("Thank you for using the program.");

        System.out.println();

        cPrintHeader("");

        cPrintHeader("");

        cPrintHeader("");

        cPrintHeader("");

        //Causes the thread to sleep. gives the reader time to read the help page before it goes back into main loop
        try {
            Thread.sleep(5000); //sleep time
        } catch (InterruptedException ex) {
            Logger.getLogger(LittleMe.class.getName()).log(Level.SEVERE, null, ex);
        }

        //redraw the GUI.
        LittleMe.linebreak();

        LittleMe.printConsole();
    }

    //displays the help page and the about page...
    public static void AboutHelpProgram2() {

        JOptionPane.showMessageDialog(null, "*                         *         HELP          *                             *\n\n"
                + "Click on whatever you want to do and it should take you to that page\n"
                + "As for LittleMe game, it is a math game developed for kids. Other information is\n"
                + "explained in program boot up.\n\n"
                + "*                         *        ABOUT          *                             *\n\n"
                + "This program is written by Ayodele Owoyele.\n"
                + "Thank you for using the program.\n", "Little Me", JOptionPane.INFORMATION_MESSAGE);
    }

    //constructor for the Little Me class. I thought I was going to use it, but I didn't
    public LittleMe() {
        input = new Scanner(System.in);  //for collecting the user input 

        printConsole(); //prints the console
    }

//this method searches for the audio file and plays it.
    public static void playsound(String soundname) {

        String soundbutt;
        String path;
        File f = new File(System.getProperty("java.class.path")); //this line of code obtains the java class path directory 
        File dir = f.getAbsoluteFile().getParentFile(); //this line of code gets the directory
        path = dir.toString(); //this line converts the directory to string
        soundbutt = "\\sounds\\" + soundname; //this adds sound directory level to the directory
        sound = new MP3Player(new File(path + soundbutt)); //the downloaded import file from the internet that plays MP3 sound
        sound.play(); //this acutally plays the sound 

    }

    //this is the main method
    public static void main(String[] args) {

        if (args.length > 0) {
            LittleMe me = new LittleMe();

        } else {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    LittleMe gui = new LittleMe(true); //GUI GAME
                }
            });
        }

    }

    //this method decides whether to terminate the program or not
    public static void quitProgram() {

        Q("Do you want to quit the program (y, n) ");

        userOption = input.next();

        if (userOption.equalsIgnoreCase("y")) { //if the user enters yes

            System.out.println(); //for formatting purpose only

            System.out.println(); //for formatting purpose only

            playsound("goodbye.mp3"); //plays the good bye sound 

            //this slows the thread down, so that the sound will play before the program terminates
            try {
                Thread.sleep(1000); //thread actually goes to sleep here 
            } catch (InterruptedException ex) {
                // Logger.getLogger(LittleMe.class.getName()).log(Level.SEVERE, null, ex);
            }

            Message("Goodbye"); //outputs the good bye message

            linebreak(); //this draws a line using asterisks

            System.out.println(); // for formatting purpose only

            System.out.println(); // for formatting purpose only

        } else if (userOption.equalsIgnoreCase("n")) { //if the user says no

            nextSection();

            printConsole();

        } else // will rerun the proram 
        {
            System.out.println(); //for formatting purposes only 

            playsound("wrong.mp3");

            InfoS("Invalid Input");

            nextSection();

            printConsole();
        }

    }

    public static void nextSection() {
        System.out.println(); // for formatting purposes only.

        linebreak(); //draws a line

        System.out.println(); // for formatting purposes only.

    }

    //This method prints out the possible program functions and asks for what the user wants
    public static void printConsole() {

        System.out.println();
        nextSection();
        cPrintln("*                         * WELCOME TO LITTLE ME *                              *");
        nextSection();

        if (FirstRun == true) {
            FirstRun = false; //it is not the first run anymore.
            userInteractions(); //interacts with the user
        } else {
            playsound("whoosh.mp3"); //for sound effect.
        }

        printFunctions();
    }

    //This method interacts with the little kid and get to know them a little GUI method
    public static void userInteractions2() {

        LittleMe.playsound("beep.mp3");

        kidName = JOptionPane.showInputDialog(null, "Hey my friend, can you please type your name", "Little Me", JOptionPane.QUESTION_MESSAGE);

        if (kidName.isEmpty())
        {
            kidName = "Annonymous";
        }
        
        MainApplicationGUIJPanel.LblKidName.setText(kidName);

        JOptionPane.showMessageDialog(null, "Welcome " + kidName + ", " + "my name is LittleMe! And I can help you with the list on top...\n\n"
                + "I can also play with you when you are bored\n"
                + "Hey " + kidName + ", I can also solve for missing pieces. If you have almost everything,\n"
                + "but you are missing something. I can still help! I am here for you!\n"
                + "Click whatever relates to what you need to do and I will handle the rest", "Little Me", JOptionPane.INFORMATION_MESSAGE);

        playsound("welcome.mp3");
    }

    //This method interacts with the little kid and get to know them a little
    public static void userInteractions() {

        LittleMe.playsound("beep.mp3");

        cPrint("Hey my friend, can you please type your name? ");

        kidName = input.nextLine(); //collecting the kids name here

        playsound("welcome.mp3");
        System.out.println(); //for formating purposes only
        cPrintln("Welcome " + kidName + ", " + "my name is LittleMe! And I can help you with the list below...\n\n"
                + cSpace() + "I can also play with you when you are bored\n");
        playsound("whoosh.mp3"); //for sound effect.
    }

    //This method provides program functionalities
    public static void printFunctions() {
        //Squares, Rectangles, Circles, Cubes, Triangles, Trapeziums, and Cylinders

        //FirstSleep(); //for dramatic entrance. :-)
        //Print out the program functionalities 
        cPrintln("1. Square - Area");

        System.out.println();

        cPrintln("2. Rectangles - Area");

        System.out.println();

        cPrintln("3. Circles - Area, Perimeter, Sectors");

        System.out.println();

        cPrintln("4. Triangles - Area, Perimeter");

        System.out.println();

        cPrintln("5. Trapeziums - Area, Perimeter");

        System.out.println();

        cPrintln("6. Cylinders - Areas (Surface of Side), Volumes");

        System.out.println();

        cPrintln("7. Math Puzzle Games - LittleMe");

        System.out.println();

        cPrintln("8. Help/About");

        System.out.println();

        cPrintln("9. Exit");

        //LastSleep(); // for text effect
        System.out.println();// for formating purposes only

        System.out.println(); // for formating purposes only

        cPrintln("Hey " + kidName + ", I can also solve for missing pieces. If you have almost everything,\n\n"
                + cSpace() + "but you are missing something. I can still help! I am here for you!\n"); //dispays an output to the user 

        System.out.println(); // for formating purposes only

        InfoL("Enter a number for whatever relates to what you need to do,", "and I will handle the rest"); //print out info to the user 

        System.out.println(); // for formating purposes only

        //Trying to get user's selection here 
        Q("What will you like to do today ( 1 - 9 )");

        Boolean inputGood = false; // for error handling portion of the program

        //error handling portion of the program
        do {

            try {
                userChoice = Integer.parseInt(input.next());  //collect user input 

                if (userChoice >= 1 && userChoice <= 9) {
                    inputGood = true;
                } else {
                    throw new Exception();
                }

            } catch (Exception e) { //catches errors in user input and takes appropriate actions 

                System.out.println(); //for formatting purposes only 

                InfoS("Invalid Input"); //display the text invalid input, well centralized 

                playsound("wrong.mp3"); //plays the buzzer sound 

                System.out.println(); //for formating purposes only

                Q("What will you like to do today ( 1 - 9 )");

            }

        } while (inputGood == false);

        System.out.println(); //for formatting purposes only

        if (userChoice >= 1 && userChoice <= 6) {
            InfoS("Always remember to convert all measurements to the same unit"); //user interraction
        }

        decideOperation(); //call the switch for the required functionality.

    }

    //0  , 1,   2,   3    4
    //final String [] operators = {"+", "-", "x", "/", "R"}; //stores the various types of math operators
    //this method decides which class to interract with 
    public static void decideOperation() {

        nextSection(); //section breaker. Just a line

        //to decides user selection 
        switch (userChoice) {
            case 1:
                playsound("herewego.mp3"); //plays sound
                Square square = new Square(); //creating a new square object here 
                break;
            case 2:
                playsound("herewego.mp3"); //plays sound
                Rectangle rect = new Rectangle(); //creating a new rectangle object here 
                break;
            case 3:
                playsound("herewego.mp3"); //plays sound
                Circle circle = new Circle(); //creating a new circle object here 
                break;
            case 4:
                playsound("herewego.mp3"); //plays sound
                Triangles triangle = new Triangles(); //creating a new triangle object here
                break;
            case 5:
                playsound("herewego.mp3"); //plays sound
                Trapeziums trapezium = new Trapeziums(); //creating a new trapezium object here 
                break;
            case 6:
                playsound("herewego.mp3"); //plays sound
                Cylinders cylinders = new Cylinders(); //creating a new cylinder object here 
                break;
            case 7:
                playsound("herewego.mp3"); //plays sound
                LittleMeGame lmg = new LittleMeGame(); //creating the little me game here 
                break;
            case 8:
                AboutHelpProgram(); //this call the method provides information about the program
                break;
            case 9:
                quitProgram(); //this call the method that trys to exit the program
                break;

            //I could have used default here to prevent anynumber outside of 1-8, but did not think of that first. ;-(
        }

        userOption = ""; //this reset the option the user selected for next time 
    }

    //This method is for asking questions 
    public static void Q(String string) {
        cPrint("Okay " + kidName + ", " + string + " ? ");
    }

    //This method is for asking questions for difficulty level for the game 
    public static String QDef(String string) {

        LittleMe.playsound("beep.mp3"); //plays a sound

        Boolean correct; //to check input

        do {

            cPrint("Okay " + kidName + ", " + string + " ? ");

            try {

                LittleMe.userOption = LittleMe.input.next();

            } catch (Exception e) {
                System.out.println(); //for formatting purposes only 

                playsound("wrong.mp3");

                InfoS("Invalid Input");

                System.out.println(); //for formating purposes only
            }

            if (LittleMe.userOption.equalsIgnoreCase("robot") || LittleMe.userOption.equalsIgnoreCase("easy") || LittleMe.userOption.equalsIgnoreCase("medium") || LittleMe.userOption.equalsIgnoreCase("hard")) {
                correct = true;
            } else {
                correct = false;

                System.out.println(); //for formatting purposes only 

                playsound("wrong.mp3");

                InfoS("Invalid Input");

                System.out.println(); //for formating purposes only
            }
        } while (correct == false);

        return LittleMe.userOption; //returns user option

    }

    //This method provide information to the user - Short Information Message
    public static void InfoS(String string) {
        FirstSleep();
        LittleMe.playsound("beep.mp3");
        cPrintln("Hey " + kidName + ", " + string + "!\n");
        LastSleep();
    }

    //Message to user
    public static void Message(String string) {
        FirstSleep(); //for dramatic effect
        LittleMe.playsound("beep.mp3");
        cPrintln(string + ", " + kidName + "\n");
        LastSleep(); //for dramatic effect

    }

    //Message to user
    public static void MessageNoName(String string) {
        FirstSleep(); //for dramatic effect
        LittleMe.playsound("beep.mp3"); //plays the beep sound 
        cPrintln(string + "\n");
        LastSleep(); //for dramatic effect

    }

//slow down the thread for dramatic effect
    public static void LastSleep() {
        //Slows the the thread to give user time to read message.
        try {
            Thread.sleep(1000); //thread sleeps for 1000milliseconds
        } catch (InterruptedException ex) {
            //Logger.getLogger(Circle.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
//slow down the thread for dramatic effect

    public static void FirstSleep() {
        //Slows the the thread to give user time to read message.
        try {
            Thread.sleep(500);
        } catch (InterruptedException ex) {
            //Logger.getLogger(Circle.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //slow down the thread for dramatic effect
    public static void Sleep(int number) {
        //Slows the the thread to give user time to read message.
        try {
            Thread.sleep(number);
        } catch (InterruptedException ex) {
            //Logger.getLogger(Circle.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //This method provide information to the user - Longer Information Message
    public static void InfoL(String string, String string1) {
        cPrintln(string + "\n\n"
                + cSpace() + string1 + "\n");

    }

    //This method prints a line to separate everything...
    public static void linebreak() {
        cPrintln("*********************************************************************************");
    }

    //This method centralizes everything that is outputed
    public static void cPrintln(String string) {
        System.out.print("         " + string + "\n");
    }

    //This method centralizes everything that is outputed for heading
    public static void cPrintHeader(String string) {
        LittleMe.Sleep(300); //for dramatic effect
        LittleMe.playsound("beep.mp3");
        System.out.print("         " + string + "\n");
        LittleMe.Sleep(300); //for dramatic effect //for dramatic effect

    }

    //print the space to centralize the text
    public static String cSpace() {
        return "         ";
    }

    //This method centralizes everything that is outputed
    public static void cPrint(String string) {
        System.out.print("         " + string);
    }

    //this method asks yes or no question, with error checking. 
    public static final void varQuest(String string, String shape) {

        LittleMe.playsound("beep.mp3"); //plays a sound

        Boolean correct; //to check input

        do {

            LittleMe.Q("Do you know the " + string + " of the " + shape + " (y/n) ");

            try {

                LittleMe.userOption = LittleMe.input.next();

            } catch (Exception e) {
                System.out.println(); //for formatting purposes only 

                playsound("wrong.mp3");

                InfoS("Invalid Input");

                System.out.println(); //for formating purposes only
            }

            if (LittleMe.userOption.equalsIgnoreCase("y") || LittleMe.userOption.equalsIgnoreCase("n")) {
                correct = true;
            } else {
                correct = false;

                System.out.println(); //for formatting purposes only 

                playsound("wrong.mp3");

                InfoS("Invalid Input");

                System.out.println(); //for formating purposes only
            }
        } while (correct == false);
    }

    //this method asks yes or no question, with error checking. 
    public static final void Question(String string) {

        LittleMe.playsound("beep.mp3");

        Boolean correct; //to check input

        LittleMe.userOption = ""; //resets the variable

        do {

            LittleMe.Q(string + " (y/n) ");

            try {

                LittleMe.userOption = LittleMe.input.next();

            } catch (Exception e) {
                System.out.println(); //for formatting purposes only 

                playsound("wrong.mp3");

                InfoS("Invalid Input");

                System.out.println(); //for formating purposes only
            }

            if (LittleMe.userOption.equalsIgnoreCase("y") || LittleMe.userOption.equalsIgnoreCase("n")) {
                correct = true;
            } else {
                correct = false;

                System.out.println(); //for formatting purposes only 

                playsound("wrong.mp3");

                InfoS("Invalid Input");

                System.out.println(); //for formating purposes only
            }
        } while (correct == false);
    }

//this method is designed to collect variable and do error checking
    public static final double VarCollector(Object var, String variableName) {

        LittleMe.playsound("beep.mp3"); //plays a sound.

        LittleMe.Q("Please enter the value for the known " + variableName);

        //collect values here..do error checking
        Boolean Correct = false; //it is assuming that the user input is not correct, it has not been entered yet here

        do {
            try {
                var = Double.parseDouble(LittleMe.input.next());

                Correct = true; //terminates error checking
            } catch (Exception e) {
                System.out.println(); //for formatting purposes only

                playsound("wrong.mp3");

                InfoS("Invalid Input");

                System.out.println(); //for formating purposes only

                LittleMe.Q("Please enter the value for the known " + variableName);
            }
        } while (Correct == false);

        return Double.parseDouble(var.toString()); //return the value for the variable as a double
    }

    //this method is designed to collect variable and do error checking
    public static final int NumberQuest(Object var, String variableName) {

        LittleMe.playsound("beep.mp3"); //plays a sound.

        System.out.println(); //for formating purposes

        LittleMe.Q(variableName); //asks the question

        //collect values here..do error checking
        Boolean Correct = false; //it is assuming that the user input is not correct, it has not been entered yet here

        do {
            try {
                var = Integer.parseInt(LittleMe.input.next());

                Correct = true; //terminates error checking
            } catch (Exception e) {
                System.out.println(); //for formatting purposes only

                playsound("wrong.mp3");

                InfoS("Invalid Input");

                System.out.println(); //for formating purposes only

                LittleMe.Q(variableName); //asks the question again
            }
        } while (Correct == false);

        return Integer.parseInt(var.toString()); //return the value for the variable as a integer
    }

    //this method is designed to collect variable and do error checking for question asking
    public static final int NumberQuest(Object var, String question, int question_number) {

        LittleMe.playsound("beep.mp3"); //plays a sound.

        System.out.println(); //for formating purposes

        cPrint("Question " + question_number + ": " + question);

        //collect values here..do error checking
        Boolean Correct = false; //it is assuming that the user input is not correct, it has not been entered yet here

        do {
            try {
                var = Integer.parseInt(LittleMe.input.next());

                Correct = true; //terminates error checking
            } catch (Exception e) {
                System.out.println(); //for formatting purposes only

                playsound("wrong.mp3");

                InfoS("Invalid Input");

                System.out.println(); //for formating purposes only

                cPrint("Question " + question_number + ": " + question); //asks the question again
            }
        } while (Correct == false);

        return Integer.parseInt(var.toString()); //return the value for the variable as a integer
    }

    //anothe constructor
    private LittleMe(boolean b) {
        MainApplicationGUI newgame = new MainApplicationGUI(); //create new gui for the application    
    }
}
