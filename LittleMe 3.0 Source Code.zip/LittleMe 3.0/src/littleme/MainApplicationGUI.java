/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package littleme;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.SwingConstants;
import javax.swing.SwingWorker;
import javax.swing.Timer;

/**
 *
 * @author owoye001
 */
public class MainApplicationGUI extends javax.swing.JFrame {

    public static CardLayout cardLayout; //card layout

    public static JPanel mainPanel; //mainpanel for all other panels

    public static CardLayout cardLayoutMain; //card layout

    public static JPanel mainPanelMain; //mainpanel for all other panels
    //swing worker task class
    private final Task task; //background task to be performed. I thought I might have some later

    private JProgressBar progressbar; //progress bar for program load

    private int progress; //to determine progress update

    private Timer timer; //timer object to show program load. Might be commented out later. FOR TESTING PURPOSE ONLY

    int screenHeight;

    int screenWidth;

    public static ImageIcon[] images = new ImageIcon[6];  //six images to be loaded.

    int imageNum = 0; //starting value for the images. 

    public static String[] names = {"square.jpg", "circle.jpg", "rectangle.jpg", "trapezium.jpg", "triangle.jpg", "cylinder.jpg"};

    static Dimension screenSize;

    /**
     * Creates new form MainApplicationGUI
     */
    public MainApplicationGUI() {
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainApplicationGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainApplicationGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainApplicationGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainApplicationGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        progressbar = new JProgressBar();

        cardLayout = new CardLayout(); //card layout object here

        mainPanel = new JPanel(); //creating a new jpanel object here

        cardLayoutMain = new CardLayout(); //card layout object here for splash and first screen

        mainPanelMain = new JPanel(); //creating a new jpanel object here  for splash first screen

        screenSize = Toolkit.getDefaultToolkit().getScreenSize(); //gets the computer screen size. 

        screenHeight = (int) (screenSize.getHeight());

        screenWidth = (int) (screenSize.getWidth());

        getContentPane().setLayout(null); //set the layout of the JFrame to null

        mainPanel.setLayout(cardLayout); //set the layout of the main panel to card layout

        mainPanelMain.setLayout(cardLayoutMain); //set the layout of the main panel to card layout

        mainPanelMain.setSize(500, 300); //set the size of the JFrame to this value at first, but it will keep changing

        mainPanel.setSize(500, 300); //for the actual functionalities

        mainPanel.setLocation(365 * screenWidth / 1368, 137 * screenHeight / 768);

        //BEGIN LOAD INFORMATION REQUIRED FOR THE PROGRAM HERE.
        //-----------------------------------------------------------------------------------------
        setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR)); //changes the cursor to a wait cursor

        // Instances of javax.swing.SwingWorker are not reusuable, so
        // we create new instances as needed.
        task = new Task();

        //property change listener for the task class, changes the value of the progress bar.
        PropertyChangeListener prop = (PropertyChangeEvent pce) -> {

            if ("progress".equals(pce.getPropertyName())) {

                int progress1 = (Integer) pce.getNewValue(); //get the value of progress from background task running

                progressbar.setValue(progress1); //updates the progress bar values 
            }
        };

        task.addPropertyChangeListener(prop); //adding a property change listener to the class task

        task.execute(); //execute bckground thread

        //--------------------------END OF SWING WORKER CLASS HERE------------------------
    }

    //displays the splash screen
    public final void DisplaySplashScreen() {

        cardLayoutMain.show(mainPanelMain, "1"); //Selecting the card to be shown

        mainPanelMain.setSize(500, 300); //setting the size of the mainpanel here

        setSize(500, 300); //setting the size of the JFrame here

        setLocationRelativeTo(null); //set at the middle of the screen

    }

    //displays the manager screen 
    //for background tasks, ended up being empty
    class Task extends SwingWorker<Void, Void> {

        @Override
        protected Void doInBackground() throws Exception { //background task
            progress = 0;
            setProgress(0); //publishing progress here

            JPanel splashScreen = new SplashGUI(); //initialize the splash screen. THE SPLASH SCREEN 

            mainPanelMain.add(splashScreen, "1");

            mainPanelMain.setLocation(0, 0);

            mainPanel.setSize(600, 500); //the functionalities

        //adding the main JPanel to the JFrame here 
            getContentPane().add(mainPanelMain, -1); //adding mainPanel to the GUI at z-index -1  

        //getContentPane().add(mainPanel, 0); //adding other functionalities at z-index 0
            setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE); //will exit the application on close 

            setUndecorated(true); //NO CLOSE BUTTON AT THE TOP OF THE JFRAME

            setResizable(false); //cannot be resized.
            
            setTitle ("LittleMe v3.0");

            getContentPane().setBackground(new Color(128, 128, 128)); //setting the background color of the content pane here. 

            initComponents(); //initializing other  com[onents

            DisplaySplashScreen(); //this method displays the splash screen

            setVisible(true); //set the JFrame visible

            while (imageNum < 6) //load all images
            {
                images[imageNum] = new ImageIcon(getClass().getResource("images/" + names[imageNum]));
                imageNum++;

                progress += 5;
                setProgress(progress);
            }

            JPanel rectangleGUI = new RectangleGUI(); //initializes the rectangle GUI

            progress += 10;
            setProgress(progress);

            JPanel trapeziumGUI = new TrapeziumGUI(); //INITIALIZES THE TRAPEZIUM GUI

            progress += 10;
            setProgress(progress);

            JPanel triangleGUI = new TriangleGUI(); //initializes the triangle GUI

            progress += 10;
            setProgress(progress);

            JPanel circleGUI = new CircleGUI(); //initializes the circle GUI'

            progress += 10;
            setProgress(progress);

            JPanel squareGUI = new SquareGUI(); //initialize the SQUARE GUI

            progress += 10;
            setProgress(progress);

            JPanel littlemeGUI = new LittleMeGameGUI(); //initializes the little me game

            JPanel mainapplicationGUIJPanel = new MainApplicationGUIJPanel(); //selection menu

            JPanel cylinderGUI = new CylinderGUI(); //cylinder GUI

        //ADD PANELS TO MAIN PANEL USING CARD LAYOUT TECHNIQUE
            mainPanel.add(squareGUI, "2");

            mainPanel.add(rectangleGUI, "3");

            mainPanel.add(trapeziumGUI, "4");

            mainPanel.add(triangleGUI, "5");

            mainPanel.add(circleGUI, "6");

            mainPanel.add(littlemeGUI, "7");

            mainPanelMain.add(mainapplicationGUIJPanel, "2");

            mainPanel.add(cylinderGUI, "9");

            getContentPane().add(mainPanel, 0); //adding other functionalities at z-index 0

            progress += 20;
            setProgress(progress);

            //timer = new Timer(1000, (ActionEvent ae) -> { //timer for splash screen progress bar
            if (progress >= 100) {
                //timer.stop(); //if progress bar value is 100 or more, stop timer and display the log in screen 
                DisplayMainGUI();
            }
            //});

            //timer.start(); //starting the timer for splash screen here
            //--------------------------
            //setProgress(Math.min(progress, 100));
            return null;
        }
//displays the MAIN GUI

        public void DisplayMainGUI() {

            cardLayoutMain.show(mainPanelMain, "2"); //Selecting the card to be shown

            cardLayout.show(mainPanel, "2"); //Selecting the card to be shown square

            mainPanelMain.setSize(screenWidth, screenHeight); //setting the size of the mainpanel here

            setSize(screenWidth, screenHeight); //setting the size of the JFrame here

            setLocationRelativeTo(null); //set at the middle of the screen

            timer = new Timer(500, (ActionEvent ae) -> { //timer for splash screen progress bar
                LittleMe.userInteractions2(); //take information about user's name
                timer.stop();
            });
            timer.setRepeats(false);
            timer.start();

        }
//this method runs when the background task is complete

        @Override
        public void done() {
            setCursor(Cursor.getDefaultCursor()); // turn off the wait cursor

        }

    }

    //this class represents the splash screen
    public class SplashGUI extends JPanel {
        //--------------------------SPLASH SCREEN PANEL---------------------------------------//

        public SplashGUI() //displays the splash screen
        {
            setBackground(new Color(255, 204, 204));
            setSize(500, 300);
            setLayout(null);

            JLabel JLabelProgramName = new JLabel("<html> LITTLE<br> &nbsp "
                    + "ME v3.0 </html>", SwingConstants.CENTER); //displays the hotel name
            JLabelProgramName.setBounds(68, 52, 364, 165);
            JLabelProgramName.setForeground(new Color(255, 165, 0));
            JLabelProgramName.setBackground(Color.red);
            JLabelProgramName.setFont(new java.awt.Font("BatangChe", Font.PLAIN, 50)); // setting the font size here
            add(JLabelProgramName);

            progressbar = new JProgressBar();
            progressbar.setBounds(20, 256, 452, 31);
            progressbar.setValue(0);
            progressbar.setBackground(new Color(128, 128, 128));
            progressbar.setBorderPainted(true);

            add(progressbar);
            //------------------------------END OF SPLASH SCREEN PANEL-----------------------------------------
        }//END CONSTRUCTOR HERE
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 566, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 492, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
